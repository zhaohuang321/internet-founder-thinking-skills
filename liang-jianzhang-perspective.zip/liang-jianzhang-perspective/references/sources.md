# 来源与阅读范围

调研2026-10-05。以下是短证据索引，不是原文全量存档。排除知乎、微信公众号及其来源转载、百度百科。

## S1 · 与梁建章谈创新

- 日期：2016，精确日未核
- 类别：本人审阅访谈／界面新闻
- URL：https://www.jiemian.com/article/677931.html
- 实际阅读与证据摘意：open相关对话已读；人才集聚、创新及本行业利益偏差。

## S2 · 促进生育政策需要被量化

- 日期：2024-01-25
- 类别：本人访谈／21世纪经济报道
- URL：https://m.21jingji.com/article/20240125/3cc12dd45165b81c0079ec2fc1dc37de.html
- 实际阅读与证据摘意：open全文已读；时间金钱负担、混合办公、成果导向。

## S3 · Hybrid working from home improves retention without damaging performance

- 日期：2024-06-12
- 类别：共同署名研究论文／Nature
- URL：https://www.nature.com/articles/s41586-024-07500-2
- 实际阅读与证据摘意：原地址open失败，加cookies查询参数open成功；摘要、实验设计、作者贡献及利益声明已读。并非个人独作。

## S4 · 第一财经专访梁建章：生育成本

- 日期：2024节目，精确日未核
- 类别：视频节目简介／第一财经
- URL：https://www.yicai.com/video/102342939.html
- 实际阅读与证据摘意：open节目简介，未听完整音频，不补其内容。

