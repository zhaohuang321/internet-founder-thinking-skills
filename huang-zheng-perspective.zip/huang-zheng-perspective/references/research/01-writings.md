# 著作与长文

2018年《财经》访谈和2019、2020年官方署名股东信，3条实际打开材料。未核验独立著作；2020信中的物理类比不作为科学结论。

- [S1：对话：他们建帝国、争地盘，我要错位竞争](https://finance.sina.com.cn/chanjing/gsnews/2018-04-04/doc-ifyteqtq3840756.shtml)
- [S2：2019年致股东信](https://www.yangkeduo.com/home/static/pdf/2019-letter-to-shareholders.pdf)
- [S3：2020年致股东信](https://www.yangkeduo.com/home/static/pdf/2020-letter-to-shareholders.pdf)

没有全书正文不写“通读”；荐书不等于著作，传记作者与被传主严格区分。

六维入口：[对话](02-dialogues.md)、[表达](03-expression.md)、[他者](04-others.md)、[决策](05-decisions.md)、[时间线](06-timeline.md)。详见[来源表](../sources.md)。
