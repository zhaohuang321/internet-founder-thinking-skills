# 著作与长文

2015年凤凰访谈、2016年授权书摘、2018年口述书摘及书目核验。4条实际打开材料；两种口述著作仅读公开片段，未通读整本书。

- [S1：36氪领读：战略、管理仅靠几张表](https://www.36kr.com/p/1722729316353)
- [S2：澎湃授权《刘强东自述：我的经营模式》节选](https://m.thepaper.cn/newsDetail_forward_1494544)
- [S3：凤凰《总裁在线》访谈实录](https://finance.ifeng.com/c/7cGApASiWvd)
- [S4：Google Books：刘强东自述：我的经营模式](https://books.google.com/books/about/%E5%88%98%E5%BC%BA%E4%B8%9C%E8%87%AA%E8%BF%B0.html?id=pKaE0AEACAAJ)

没有全书正文不写“通读”；荐书不等于著作，传记作者与被传主严格区分。

六维入口：[对话](02-dialogues.md)、[表达](03-expression.md)、[他者](04-others.md)、[决策](05-decisions.md)、[时间线](06-timeline.md)。详见[来源表](../sources.md)。
