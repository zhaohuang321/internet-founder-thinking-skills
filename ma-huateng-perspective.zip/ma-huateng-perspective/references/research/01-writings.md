# 著作与长文

2012年公开信、产品设计讲座转载和2017年清华演讲整理稿。3项可访问材料；没有通读其合作署名书籍，书本思想不作为已完成研究。

- [S1：灰度法则的七个维度](https://tech.sina.com.cn/i/2012-07-09/11477365858.shtml)
- [S2：用户体验的10/100/1000法则](https://ixdc.org/?wx=736)
- [S3：清华详解腾讯AI生态布局](https://tech.sina.cn/it/2017-09-09/detail-ifykusey6272717.d.html?sinawapsharesource=newsapp)

没有全书正文不写“通读”；荐书不等于著作，传记作者与被传主严格区分。

六维入口：[对话](02-dialogues.md)、[表达](03-expression.md)、[他者](04-others.md)、[决策](05-decisions.md)、[时间线](06-timeline.md)。详见[来源表](../sources.md)。
