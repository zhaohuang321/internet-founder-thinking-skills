# 著作与长文

2016年新京报、2017年钱江晚报和《商业周刊/中文版》访谈转载。3条实际打开材料；未核验本人独立著作，不把他人写的网易传记算本人书。

- [S1：新京报访谈：如果2017年创业还会养猪](https://finance.sina.com.cn/chanjing/gsnews/2016-11-01/doc-ifxxfysn8320127.shtml)
- [S2：钱江晚报访谈：年轻人不要太急于创业](https://finance.sina.com.cn/manage/crz/2017-02-04/doc-ifyafcyw0112361.shtml)
- [S3：《商业周刊/中文版》专访：互联网品味家](https://tech.sina.cn/i/gn/2017-08-05/detail-ifyitamv5571889.d.html?wm=3049_0015)

没有全书正文不写“通读”；荐书不等于著作，传记作者与被传主严格区分。

六维入口：[对话](02-dialogues.md)、[表达](03-expression.md)、[他者](04-others.md)、[决策](05-decisions.md)、[时间线](06-timeline.md)。详见[来源表](../sources.md)。
