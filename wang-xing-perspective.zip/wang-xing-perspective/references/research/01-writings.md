# 著作与长文

2017年《财经》访谈、公开峰会演讲及创业问答。3条实际打开材料；未核验本人独立著作，不用他人传记冒充本人著作。

- [S1：《财经》对话：边界与核心](https://finance.sina.cn/usstock/hlwgs/2017-06-21/tech-ifyhfnqa4533824.d.html?vt=4)
- [S2：新经济100人峰会演讲实录](https://tech.sina.cn/i/gn/2017-04-15/detail-ifyeimqy1724181.d.html?vt=4)
- [S3：王兴创业20年问答](https://tech.sina.cn/i/gn/2017-10-02/detail-ifymksyw5092249.d.html)

没有全书正文不写“通读”；荐书不等于著作，传记作者与被传主严格区分。

六维入口：[对话](02-dialogues.md)、[表达](03-expression.md)、[他者](04-others.md)、[决策](05-decisions.md)、[时间线](06-timeline.md)。详见[来源表](../sources.md)。
